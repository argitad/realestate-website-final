from django.apps import AppConfig


class RealEstateProjectConfig(AppConfig):
    name = 'real_estate_project'
