from django.http import HttpResponse
from django.shortcuts import render
from .models import *
from django.core.paginator import Paginator


# Create your views here.

def home(request):
    homes = Pronat.objects.all().order_by('id_prones')[::-1]
    context = {'homes': homes}
    return render(request, 'home.html', context)


def listprona(request):
    homes = Pronat.objects.all()
    pagess = Pronat.objects.all().order_by('id_prones')[::-1]
    # prona_cat = Category.objects.get(category = cat)
    category = None
    categories = Category.objects.all()
    pagess = pagess.filter(category=category)
    paginator = Paginator(pagess, 6)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    propertylist = Pronat.objects.all()
    agjent = Agjent.objects.all()
    context = {'homes': homes, 'propertylist': propertylist, 'agjent': agjent, 'page_obj': page_obj, 'categories': categories}
    return render(request, 'listprona.html', context)

# def apartamente(request, kat):
#     propertylist = Pronat.objects.all()
#     property = Pronat.objects.get(id_prones=id)
#     apartamente = Pronat.objects.filter(kategoria=kat)
#     pagess = Pronat.objects.all()
#     paginator = Paginator(pagess, 6)
#     page_number = request.GET.get('page')
#     page_obj = paginator.get_page(page_number)
#     agjent = Agjent.objects.all()
#     context = {'agjent': agjent, 'page_obj': page_obj, 'propertylist': propertylist, 'apartamente': apartamente, 'property': property}
#     return render(request, 'Apt.html', context)


def prona(request, id):
    homes = Pronat.objects.all().order_by('id_prones')[::-1]
    prona = Pronat.objects.all()
    property = Pronat.objects.get(id_prones=id)
    fotopron=ImazheProna.objects.filter(prona_title=property)
    img_pronat = ImazheProna.objects.all()
    agjent = Agjent.objects.all()
    context = {'homes': homes, 'property': property, 'img_pronat': img_pronat, 'agjent': agjent, 'fotopron': fotopron, 'prona': prona}
    return render(request, 'prona.html', context)