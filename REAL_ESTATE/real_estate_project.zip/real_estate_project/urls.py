from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('listprona/', views.listprona, name='listprona'),
    # path('listprona/category/apartamente', views.apartamente, name='Apart'),
    # path('apt/', views.apt, name='apt'),
    path('prona/<id>', views.prona, name='prona'),
]